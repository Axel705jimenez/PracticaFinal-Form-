﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoAxel
{
    class Puntos
    {
        private int puntos1;

        public int Puntos1
        {
            get { return puntos1; }
            set { puntos1 = value; }
        }
        public Puntos()
        {
            puntos1 = 100;
        }
        public override string ToString()
        {
            return puntos1 + 10 + base.ToString();
        }
    }
}
